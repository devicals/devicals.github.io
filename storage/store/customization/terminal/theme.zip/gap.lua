clink.onendedit(function(line)
    if line and line ~= "" then
        print("\n\x1b[38;2;255;255;255m// OUTPUT\x1b[0m")
    end
end)