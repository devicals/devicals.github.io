# Note
The files in this `.zip` file are configs for **[clink](https://github.com/chrisant996/clink)** & **[starship](https://github.com/starship/starship)**.
These were crafted for the **Windows Command Prompt (CMD)**, but may work with other shells like Powershell.

### Using Other Shells
For use in other shells, please refer to each program's own documentation:

[clink](https://github.com/chrisant996/clink): [`https://chrisant996.github.io/clink/`](https://chrisant996.github.io/clink/)\
[starship](https://github.com/starship/starship): [`https://starship.rs/`](https://starship.rs/)\
[zoxide](https://github.com/ajeetdsouza/zoxide): [`https://crates.io/crates/zoxide`](https://crates.io/crates/zoxide)

# Screenshots
![Screenshot](screenshot_1.png)
![Screenshot](screenshot_2.png)

# Dependencies
### Required
[clink](https://github.com/chrisant996/clink): `scoop install clink`\
[starship](https://github.com/starship/starship): `scoop install starship`

### Optional
[zoxide](https://github.com/ajeetdsouza/zoxide): `scoop install zoxide`

# Configuration
### Config Locations
`gap.lua` and `starship.lua` should go in your **[clink](https://github.com/chrisant996/clink)** folder, at `%appdata%/../local/clink`.
You can easily access the folder by pressing `WIN` + `R` and entering `%appdata%/../local/clink` and hit `ENTER`.

[Zoxide](https://github.com/ajeetdsouza/zoxide) does not internally support cmd, but does still work. Using a custom user-made script for it, placed in `starship.lua`, you can run [Zoxide](https://github.com/ajeetdsouza/zoxide) in the cmd terminal!
> Aliases: `z`, `zi`, `cd`, `cdi`.

`starship.toml` should go in your **.config** folder, at `%USERPROFILE%/.config`.
Again, you can easily acess the folder by entering `%USERPROFILE%/.config` into the Windows Run prompt.

### Setting Clink Theme
Once you have [clink](https://github.com/chrisant996/clink) installed, you can simply just **run** `clink_colors.bat` and it will automatically set the color theme.

# Attributions
Theme & Config by Error Dev.